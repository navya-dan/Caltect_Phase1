package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class AddClientPage {
  private WebDriver driver;
  public AddClientPage() {
	  System.setProperty("webdriver.chrome.driver", "C:\\Users\\hp\\Downloads\\chromedriver-win32\\chromedriver-win32\\chromedriver.exe");
	  driver=new ChromeDriver();
  }
  public void navigateTo() {
		driver.get("http://localhost:4200/clientregister");
	}
	
	
	public void enterClientdetails() {
		driver.findElement(By.name("id")).sendKeys("6");
		driver.findElement(By.name("name")).sendKeys("keerthana");
		driver.findElement(By.name("email")).sendKeys("keerthana.chamarthy@gmail.com");
		driver.findElement(By.name("address")).sendKeys("Rajamundry");
		driver.findElement(By.name("password")).sendKeys("keerthana");
		driver.findElement(By.name("repeatpassword")).sendKeys("keerthana");
		driver.findElement(By.name("register")).click();
	}
	
	public String isClientAdded() {
		return driver.findElement(By.name("h1")).getText();
	}
	
	public void closeBrowser() {
		driver.quit();
	}
  
}
