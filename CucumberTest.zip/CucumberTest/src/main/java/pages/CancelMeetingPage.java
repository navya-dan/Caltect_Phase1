package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class CancelMeetingPage {
	private WebDriver driver;
	  public CancelMeetingPage() {
		  System.setProperty("webdriver.chrome.driver", "C:\\Users\\hp\\Downloads\\chromedriver-win32\\chromedriver-win32\\chromedriver.exe");
		  driver=new ChromeDriver();
	  }
	  public void navigateTo() {
			driver.get("http://localhost:4200/viewclientmeetings");
		}
		
		
		public void clickCancelMeeting() {
			driver.findElement(By.xpath("/html/body/app-root/app-view-meetings/table/tr[2]/td[6]/button")).click();
		}
		
		public String isClientMeetingCencelled() {
			return driver.findElement(By.name("h1")).getText();
		}
		
		public void closeBrowser() {
			driver.quit();
		}
}
