package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class AddClientMeetingPage {
	private WebDriver driver;
	  public AddClientMeetingPage() {
		  System.setProperty("webdriver.chrome.driver", "C:\\Users\\hp\\Downloads\\chromedriver-win32\\chromedriver-win32\\chromedriver.exe");
		  driver=new ChromeDriver();
	  }
	  public void navigateTo() {
			driver.get("http://localhost:4200/clientmeeting");
		}
		
		
		public void enterClientMeetingdetails() {
			driver.findElement(By.name("id")).sendKeys("8");
			driver.findElement(By.name("topic")).sendKeys("To talk about global warming");
			driver.findElement(By.name("count")).sendKeys("10");
			driver.findElement(By.name("start-date-time")).sendKeys("09/13/2023 03:00 PM");
			driver.findElement(By.name("end-date-time")).sendKeys("09/13/2023 04:00 PM");
			driver.findElement(By.name("submit")).click();
		}
		
		public String isClientMeetingAdded() {
			return driver.findElement(By.name("h1")).getText();
		}
		
		public void closeBrowser() {
			driver.quit();
		}
}
