package stepdefinations;

import static org.junit.Assert.assertEquals;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.AddClientPage;

public class AddClientSteps {
    private AddClientPage addClientPage=new AddClientPage();
    @Given("the user is on the client Register page")
    public void navigateToAddClient() {
    	addClientPage.navigateTo();
    }
    @When("the user enters client details and click on the Register button")
    public void enterClientDetails() {
    	addClientPage.enterClientdetails();
    }
    @Then("the new client added successfully message should be the output on the page")
    public void addedSuccessfully() {
    	assertEquals("Client details added successfully",addClientPage.isClientAdded());
    	addClientPage.closeBrowser();
    }
}
