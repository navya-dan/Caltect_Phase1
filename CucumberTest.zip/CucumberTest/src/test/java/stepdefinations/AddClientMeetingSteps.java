package stepdefinations;

import static org.junit.Assert.assertEquals;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.AddClientMeetingPage;

public class AddClientMeetingSteps {
	private AddClientMeetingPage addClientMeetingPage = new AddClientMeetingPage();
	@Given("the user is on the schedule meeting page")
	 public void navigateToAddMeeting() {
    	addClientMeetingPage.navigateTo();
    }
    @When("the user enters meeting details and click on the submit button")
    public void enterClientMeteingDetails() {
    	addClientMeetingPage.enterClientMeetingdetails();
    }
    @Then("the client meeting details added successfully message should be the output on the page")
    public void addedSuccessfully() {
    	assertEquals("Client Meeting details added successfully",addClientMeetingPage.isClientMeetingAdded());
    	addClientMeetingPage.closeBrowser();
    }
}
