package stepdefinations;

import static org.junit.Assert.assertEquals;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.CancelMeetingPage;

public class CancelMeetingSteps {
	private CancelMeetingPage cancelMeetingPage=new CancelMeetingPage();
    @Given("the user is on view all scheduled meetings page")
    public void navigateToViewMeeting() {
    	cancelMeetingPage.navigateTo();
    }
    @When("the user click on the cancel button")
    public void clickCancelMeeting() {
    	cancelMeetingPage.clickCancelMeeting();
    }  
    @Then("the client meeting cancelled successfully message should be the output on the page")
    public void addedSuccessfully() {
    	assertEquals("Meeting cancelled successfully",cancelMeetingPage.isClientMeetingCencelled());
    	cancelMeetingPage.closeBrowser();
    }
    
}
