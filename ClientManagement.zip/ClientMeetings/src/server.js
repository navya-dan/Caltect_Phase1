const express=require('express');
const bodyParser=require('body-parser');
const cors=require('cors')
const mysql=require('mysql')

const app=express();
const port=3000;

app.use(cors())
app.use(bodyParser.json())


const db=mysql.createConnection({
    host:'localhost',
    user:'root',
    password:'root',
    database: 'db2'
});


db.connect(err=>{
    if(err){
        console.error("connection is not established with the db",err);
    }
    else{
        console.log("connected to the db");
    }
});

app.listen(port,()=>{"server port established on 3000"})
app.post('/addClient',(req,res)=>{
    const {id,name,email,address,password}=req.body;
    const sql='insert into client values(?,?,?,?,?)';
    db.query(sql,[id,name,email,address,password],(err,result)=>{
        if(err){
            console.error('error in adding the client details',err);
            res.status(500).json({error:'An error occured'})
        }
        else{
            res.status(200).json({message:'Client details added successfully'});
        }
    });
});
app.post('/addClientMeeting',(req,res)=>{
    const {id,meetingtopic,noofpeople,datetimestart,datetimeend}=req.body;
    const sql='insert into meeting values(?,?,?,?,?)';
    db.query(sql,[id,meetingtopic,noofpeople,datetimestart,datetimeend],(err,result)=>{
        if(err){
            console.error('error in adding the client meeting details',err);
            res.status(500).json({error:'An error occured'})
        }
        else{
            res.status(200).json({message:'Client Meeting details added successfully'});
        }
    });
});

app.get('/getMeetings',(req,res)=>{
    const sql='select * from meeting';
    db.query(sql,(err,result)=>{
        if(err){
            console.error('error in fetching the meeting details',err);
            res.status(500).json({error:'An error occured'})
        }
        else{
            console.log(result);
            res.status(200).json(result);
        }
    });
});

app.delete('/deleteMeeting/:idm',(req,res)=>{
    const idm=req.params.idm;
    const sql='delete from meeting where idm=?';
    db.query(sql,[idm],(err,result)=>{
        if(err){
        console.error('Error in cancelling the meeting',err);
        res.status(500).json({error:'An error occured'});
    }else{
        res.status(200).json({message:'Meeting cancelled successfully'});
    }
   
    });
    });



