import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ClientManagementComponent } from './client-management/client-management.component';
import { ClientMeetingManagementComponent } from './client-meeting-management/client-meeting-management.component';
import { RouterModule, Routes } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { ViewMeetingsComponent } from './view-meetings/view-meetings.component';

const routes:Routes=[
  {path: 'clientregister',component:ClientManagementComponent},
  {path: 'clientmeeting', component:ClientMeetingManagementComponent},
  {path: 'viewclientmeetings', component:ViewMeetingsComponent}
]

@NgModule({
  declarations: [
    AppComponent,
    ClientManagementComponent,
    ClientMeetingManagementComponent,
    ViewMeetingsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    RouterModule.forRoot(routes)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
