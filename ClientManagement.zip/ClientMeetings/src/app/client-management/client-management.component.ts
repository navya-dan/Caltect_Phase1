import { HttpClient } from '@angular/common/http';
import { Component , OnInit} from '@angular/core';
import { response } from 'express';

@Component({
  selector: 'app-client-management',
  templateUrl: './client-management.component.html',
  styleUrls: ['./client-management.component.css']
})
export class ClientManagementComponent {
  id:number=0;
  message:string=''
  name:string='';
  email:string='';
  address:string='';
  password:string='';
  repeatpassword:string='';
  constructor(private http:HttpClient) { }
  ngOnInit(): void {
  }
  createClient(){
   if(this.password!=this.repeatpassword){
    alert("password and Repeat password do not match");
   }
   else{
    const client={
      id:this.id,
      name:this.name,
      email:this.email,
      address:this.address,
      password:this.password
    };
    this.http.post('http://localhost:3000/addClient',client).subscribe((response:any)=>{
      this.message=response.message
    },
     (error)=>{
      console.error('Error adding the client details',error);
     }
    );
   }
  }
}
