import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-client-meeting-management',
  templateUrl: './client-meeting-management.component.html',
  styleUrls: ['./client-meeting-management.component.css']
})
export class ClientMeetingManagementComponent {
     id:number=0;
     message:string='';
     meetingtopic:string='';
     noofpeople:Number=0;
     datetimestart:string='';
     datetimeend:string='';
     constructor(private http:HttpClient){}
     ngOnInit(): void{

     }
     createMeeting(){
        const clientMeeting={
          id:this.id,
          meetingtopic:this.meetingtopic,
          noofpeople:this.noofpeople,
          datetimestart:this.datetimestart,
          datetimeend:this.datetimeend
        };
        this.http.post('http://localhost:3000/addClientMeeting',clientMeeting).subscribe((response:any)=>{
          this.message=response.message
        },
         (error)=>{
          console.error('Error adding the client meeting details',error);
         }
        );
     }
}
