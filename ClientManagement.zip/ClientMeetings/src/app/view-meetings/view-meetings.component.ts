import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';

@Component({
  selector: 'app-view-meetings',
  templateUrl: './view-meetings.component.html',
  styleUrls: ['./view-meetings.component.css']
})
export class ViewMeetingsComponent {
  meetings:any[]=[];
  message:string='';
  constructor(private http:HttpClient) { }
  ngOnInit(): void {
      this.fetchMeetings();
  }


  fetchMeetings(){
    this.http.get('http://localhost:3000/getMeetings')
      .subscribe((response:any)=>
    {this.meetings=response},
    (error)=>{console.error('Error fetching the meeting details',error);}
  );
  }
  cancelMeeting(idm:number){
    if(confirm('Are you sure you want to cancel this meeting?')){
      this.http.delete('http://localhost:3000/deleteMeeting/'+idm)
      .subscribe((response:any)=>
    {this.message=response.message;
     
      this.fetchMeetings();},
   
    (error)=>{console.error('Error canceling the meeting',error);}
  );
}
}

}
